/***
 * Project: Culminating
 * Programmer: Waqar Ul-Hassan
 * Date: January 22, 2020
 * Program: Culminating.java
 */
package culminating;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.Scanner;

public class Culminating extends JPanel{

    //global variables
    public static JFrame menu, nextm1, nextmA; //frame variable
    public static JButton start1, startA; //button to start 1 vs. 1/A.I
    public static JPanel T1, T2, T3, M1, M2, M3, B1, B2, B3;
    public static JLabel WP;
    public static JPanel[] Top = new JPanel[3];
    public static JPanel[] Mid = new JPanel[3];
    public static JPanel[] Bot = new JPanel[3];
    
    public static void main(String[] args) {
        
        
        constructFrame(); //invoke frame method
        menu.setVisible(true);

        //For button start1 when clicked
        start1.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            
            menu.setVisible(false);
            nextm1.setVisible(true);
            
            
            
        }//method ends

    });
        


        //For button startA when clicked
        startA.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
           
            
        }//method ends
            
    });
        
    }
    
    public static void constructFrame() {
        //Makes frame
        //frame for main window
        menu = new JFrame("Main Menu"); //create frame object and title
        menu.setSize(600, 600); //set frame size in pixels
        menu.setLocation(400,400); 
        menu.setResizable(false); //won't let user change window size
        menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        menu.setLayout(null);
        //frame for Player vs. Player window
        nextm1 = new JFrame("Player vs. Player");//create frame object and title
        nextm1.setSize(600, 600); //set frame size in pixels
        nextm1.setLocation(400,400); 
        nextm1.setResizable(false); //won't let user change window size
        nextm1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        nextm1.setLayout(null);
        nextm1.setLayout(new GridLayout(3,3));
        //frame for Player vs. A.I window
        nextmA = new JFrame("Player vs. Computer");//create frame object and title
        nextmA.setSize(600, 600); //set frame size in pixels
        nextmA.setLocation(400,400); 
        nextmA.setResizable(false); //won't let user change window size
        nextmA.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        nextmA.setLayout(null);
        //Makes button
        start1 = new JButton("Player vs. Player");
        start1.setBounds(50, 200, 200, 100);
        menu.add(start1);
        //label initalize
        Graphics t1 = T1.getGraphics();
        t1.setColor(Color.black);
        t1.drawLine(200,0,200, 200);
        t1.drawLine(0, 200, 200, 200);
        Top[0] = T1;
        Graphics t2 = T2.getGraphics();
        t2.setColor(Color.black);
        t2.drawLine(0,200,200,200);
        t2.drawLine(0,0,0,200);
        t2.drawLine(200, 0, 200, 200);
        Top[1] = T2;
        Graphics t3 = T3.getGraphics();
        t3.setColor(Color.black);
        t3.drawLine(0,0,0,200);
        t3.drawLine(0, 200, 200, 200);
        Top[2] = T3;
        Graphics m1 = M1.getGraphics();
        m1.setColor(Color.black);
        m1.drawLine(0,0,200,0);
        m1.drawLine(200,0,200,200);
        m1.drawLine(0,200,200,200);
        Mid[0] = M1;
        Graphics m2 = M2.getGraphics();
        m2.setColor(Color.black);
        m2.drawLine(0,0,200,0);
        m2.drawLine(0, 0, 0, 200);
        m2.drawLine(0, 200, 200, 200);
        m2.drawLine(200, 0, 200, 200);
        Mid[1] = M2;
        Graphics m3 = M3.getGraphics();
        m3.setColor(Color.black);
        m3.drawLine(0,0,200,0);
        m3.drawLine(0,0,0,200);
        m3.drawLine(0,200,200,200);
        Mid[2] = M3;
        Graphics b1 = B1.getGraphics();
        b1.setColor(Color.black);
        b1.drawLine(200,0,200,200);
        b1.drawLine(0,0,200,0);
        Bot[0] = B1;
        Graphics b2 = B2.getGraphics();
        b2.setColor(Color.black);
        b2.drawLine(200,0,200, 200);
        b2.drawLine(0,0,0,200);
        b2.drawLine(200,0,200,200);
        Bot[1] = B2;
        Graphics b3 = B3.getGraphics();
        b3.setColor(Color.black);
        b3.drawLine(0,0,200, 0);
        b3.drawLine(0,0,0,200);
        Bot[2] = B3;
        startA = new JButton("Player vs. Computer");
        startA.setBounds(300, 200, 200, 100);
        menu.add(startA);

        //makes info for main window
        WP = new JLabel("Please pick one of the following");
        WP.setBounds(185, 100, 200, 50);
        menu.add(WP);
        
    }
    
    
}
