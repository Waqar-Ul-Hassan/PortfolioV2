/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package culminating;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class ConstructFrame {
    
    JPanel T1, T2, T3, M1, M2, M3, B1, B2, B3;
    JPanel[] Top = {T1, T2, T3};
    JPanel[] Mid = {M1, M2, M3};
    JPanel[] Bot = {B1, B2, B3};

    JFrame frame = new JFrame();
    
    
    ConstructFrame () {
        Graphics t1 = T1.getGraphics();
        t1.setColor(Color.black);
        t1.drawLine(200,0,200, 200);
        t1.drawLine(0, 200, 200, 200);
        
        Graphics t2 = T2.getGraphics();
        t2.setColor(Color.black);
        t2.drawLine(0,200,200,200);
        t2.drawLine(0,0,0,200);
        t2.drawLine(200, 0, 200, 200);
        
        Graphics t3 = T3.getGraphics();
        t3.setColor(Color.black);
        t3.drawLine(0,0,0,200);
        t3.drawLine(0, 200, 200, 200);
        
        Graphics m1 = M1.getGraphics();
        m1.setColor(Color.black);
        m1.drawLine(0,0,200,0);
        m1.drawLine(200,0,200,200);
        m1.drawLine(0,200,200,200);
        
        Graphics m2 = M2.getGraphics();
        m2.setColor(Color.black);
        m2.drawLine(0,0,200,0);
        m2.drawLine(0, 0, 0, 200);
        m2.drawLine(0, 200, 200, 200);
        m2.drawLine(200, 0, 200, 200);
        
        Graphics m3 = M3.getGraphics();
        m3.setColor(Color.black);
        m3.drawLine(0,0,200,0);
        m3.drawLine(0,0,0,200);
        m3.drawLine(0,200,200,200);
        
        Graphics b1 = B1.getGraphics();
        b1.setColor(Color.black);
        b1.drawLine(200,0,200,200);
        b1.drawLine(0,0,200,0);
        
        Graphics b2 = B2.getGraphics();
        b2.setColor(Color.black);
        b2.drawLine(200,0,200, 200);
        b2.drawLine(0,0,0,200);
        b2.drawLine(200,0,200,200);
        
        Graphics b3 = B3.getGraphics();
        b3.setColor(Color.black);
        b3.drawLine(0,0,200, 0);
        b3.drawLine(0,0,0,200);
        
        frame.setLayout(new GridLayout(3,3));
        
        frame.add(T1);
        frame.add(T2);
        frame.add(T3);
        frame.add(M1);
        frame.add(M2);
        frame.add(M3);
        frame.add(B1);
        frame.add(B2);
        frame.add(B3);
        
        frame.setSize(600,600);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        frame.setVisible(true);
        T1.setVisible(true);
        T2.setVisible(true);
        T3.setVisible(true);
        M1.setVisible(true);
        M2.setVisible(true);
        M3.setVisible(true);
        B1.setVisible(true);
        B2.setVisible(true);
        B3.setVisible(true);
    }
    
}

